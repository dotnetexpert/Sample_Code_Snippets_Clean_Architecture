﻿namespace Anubis.Domain.Entities
{
    internal interface ITrackable
    {
    }
}
﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Anubis.Application.FreightCompany.Commands.FTL
{
    public class FTLDto
    {
    }
}
